// Opt-in dev acceptance runner. Uses the actual DOM keyboard/mouse handlers and
// requestAnimationFrame loop; it is excluded from production builds by Vite.
export function install(api) {
  const panel = document.createElement('aside');
  panel.style.cssText = 'position:fixed;z-index:100;right:15px;top:90px;width:390px;max-height:70vh;overflow:auto;background:#071726ed;padding:16px;border:1px solid #bda57d;font:12px/1.8 monospace;color:#cfe3ef';
  panel.innerHTML = '<button id="run-verification" style="padding:8px;background:#c8ae82;color:#172736">运行浏览器验收</button><pre id="verification-result" style="white-space:pre-wrap;margin:10px 0 0">等待运行</pre>';
  document.body.append(panel);
  const result = document.getElementById('verification-result');
  const down = code => window.dispatchEvent(new KeyboardEvent('keydown', { code, bubbles: true }));
  const up = code => window.dispatchEvent(new KeyboardEvent('keyup', { code, bubbles: true }));
  const mouse = (type, button) => (type === 'mousedown' ? document.getElementById('game') : window).dispatchEvent(new MouseEvent(type, { button, bubbles: true }));
  const wait = async seconds => {
    const end = api.player.clock + seconds, timeout = performance.now() + 18000;
    while (api.player.clock < end) {
      if (performance.now() > timeout) throw Error('simulation paused or timed out');
      await new Promise(requestAnimationFrame);
    }
  };
  let count = 0;
  const check = (condition, label) => { if (!condition) throw Error(label); count++; result.textContent += `\n✓ ${label}`; };
  document.getElementById('run-verification').onclick = async () => {
    result.textContent = '运行中：真实 WebGL + 输入事件 + 固定步长'; count = 0;
    panel.style.pointerEvents = 'none';
    try {
      document.getElementById('start').click(); await wait(.08);
      check(api.snapshot().active && api.snapshot().calls > 20, '3D 渲染与进入训练');
      down('KeyW'); down('ShiftLeft'); await wait(.65);
      check(api.player.speed > 12, 'W + Shift 冲刺');
      down('KeyC'); await wait(.08); check(api.player.state === 'slide', 'C 滑铲');
      down('Space'); await wait(.08); up('Space'); up('KeyC');
      check(api.player.bulletUsed && api.player.position.y > .5, 'C + 空格子弹跳');
      await wait(.10); down('Space'); await wait(.08); up('Space');
      check(api.player.doubleUsed && api.player.velocity.y > 6, '子弹跳接二段跳');
      down('KeyQ'); await wait(.08); up('KeyQ'); check(api.player.airRollUsed, '二段跳接空中翻滚');
      await wait(.4); mouse('mousedown', 2); await wait(.15);
      check(api.player.state === 'glide', '鼠标右键滑翔'); mouse('mouseup', 2); up('KeyW'); up('ShiftLeft');
      api.teleport(1); down('KeyW'); down('ShiftLeft'); await wait(.50); down('KeyC'); await wait(.75);
      check(api.player.position.z < 12 && api.player.height < 1, '地图低矮通道可通过');
      up('KeyC'); await wait(.08); check(api.player.height < 1, '通道内不会穿顶站起'); up('KeyW'); up('ShiftLeft');
      api.teleport(2); down('KeyW'); down('Space'); await wait(.85);
      check(api.player.state === 'wallClimb' && api.player.position.y > 3, '真实墙面连续纵向蹬墙');
      up('Space'); mouse('mousedown', 2); await wait(.18);
      check(api.player.state === 'latch', '壁面攀附');
      down('Space'); await wait(.07); up('Space'); mouse('mouseup', 2); up('KeyW');
      check(api.player.velocity.x < -5, '攀附后蹬墙跳离');
      api.teleport(4); down('KeyX'); await wait(.08); up('KeyX'); check(!!api.player.rope, 'X 上绳');
      down('KeyW'); await wait(.4); up('KeyW'); check(api.player.position.x > -16, '绳索上沿线移动');
      down('KeyW'); down('Space'); await wait(.16); up('Space'); up('KeyW');
      check(!api.player.rope && api.player.velocity.y > 5, '空格跳离绳索');
      down('KeyE'); await wait(.08); up('KeyE'); check(api.player.velocity.y < -30, 'E 俯冲落地');
      down('KeyQ'); await wait(.08); up('KeyQ'); check(!api.player.slam, '翻滚取消俯冲');
      down('KeyR'); await wait(.08); up('KeyR'); check(Math.abs(api.player.position.x + 18) < .1, 'R 复位当前检查点');
      api.teleport(0); api.startRoute(); await wait(.1); down('KeyW'); down('ShiftLeft'); await wait(.8); up('KeyW'); up('ShiftLeft');
      check(api.snapshot().route.index >= 1, '计时路线真实穿环计数');
      down('KeyH'); up('KeyH'); await new Promise(requestAnimationFrame);
      check(!document.getElementById('modal').classList.contains('hidden') && !api.snapshot().active, 'H 操作指南暂停游戏');
      check(document.querySelectorAll('.checklist .done').length >= 10, '已体验动作清单同步');
      result.textContent += `\n\nPASS ${count} / ${count}`;
      document.getElementById('close-modal').click(); api.teleport(0);
    } catch (error) { result.textContent += `\n\nFAIL: ${error.stack}`; document.getElementById('menu-button').click(); }
    finally { panel.style.pointerEvents = 'auto'; }
  };
}

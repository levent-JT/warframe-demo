import * as THREE from 'three';
import { MovementController, DEFAULTS, LABELS } from './movement.js';
import { createScene, createCharacter, createTrails } from './scene.js';
import { solids, spawns, gates } from './world.js';

const $ = id => document.getElementById(id);
const safeStore = {
  get(key) { try { return localStorage.getItem(`kinetic.${key}`); } catch { return null; } },
  set(key, value) { try { localStorage.setItem(`kinetic.${key}`, value); } catch { /* private browsing */ } },
};
const canvas = $('game');
let world;
try { world = createScene(canvas); }
catch (error) {
  $('error').classList.remove('hidden');
  $('error').textContent = `无法启动 WebGL 3D 场景。请使用开启硬件加速的 Chrome 或 Edge。详细信息：${error.message}`;
  throw error;
}
const { scene, camera, renderer, collisionMeshes, gateMeshes } = world;
const character = createCharacter(scene), trail = createTrails(scene);
const player = new MovementController();
for (let i = 0; i < 8; i++) player.step(1 / 120);
player.events.length = 0;
scene.updateMatrixWorld(true);

let active = false, yaw = 0, pitch = -.14, snapCamera = true, accumulator = 0;
let sensitivity = Number(safeStore.get('sensitivity')) || .0022;
let baseFov = Number(safeStore.get('fov')) || 69;
let toastTimer = 0, dragging = false, shiftDownAt = 0, totalTime = 0;
let route = { active: false, finished: false, index: 0, time: 0, best: Number(safeStore.get('best')) || 0 };
let audioContext, soundEnabled = safeStore.get('sound') !== 'false';
const held = new Set(), edges = new Set(), visited = new Set(), history = [];
const fixed = 1 / 120, raycaster = new THREE.Raycaster();
const speedBars = [];
for (let i = 0; i < 18; i++) { const el = document.createElement('i'); $('speed-bars').append(el); speedBars.push(el); }

function toast(message, duration = 3200) {
  $('toast').textContent = message; $('toast').classList.add('show'); toastTimer = duration / 1000;
}
function beep(event) {
  if (!soundEnabled || !audioContext) return;
  const tones = { bullet: [180, 720, .17], double: [300, 550, .10], jump: [210, 350, .09],
    airRoll: [360, 160, .12], land: [100, 55, .08], hardLand: [70, 32, .16], wallClimb: [180, 220, .035], wallRun: [190, 240, .035], latch: [430, 180, .12] };
  const tone = tones[event]; if (!tone) return;
  const osc = audioContext.createOscillator(), gain = audioContext.createGain();
  const t = audioContext.currentTime; osc.type = 'sine'; osc.frequency.setValueAtTime(tone[0], t);
  osc.frequency.exponentialRampToValueAtTime(tone[1], t + tone[2]);
  gain.gain.setValueAtTime(.0001, t); gain.gain.exponentialRampToValueAtTime(.025, t + .012);
  gain.gain.exponentialRampToValueAtTime(.0001, t + tone[2]); osc.connect(gain); gain.connect(audioContext.destination);
  osc.start(t); osc.stop(t + tone[2] + .02);
}
function pause() {
  active = false; held.clear(); edges.clear(); accumulator = 0;
  if (document.pointerLockElement) document.exitPointerLock();
  $('menu').classList.remove('hidden'); $('session-card').classList.remove('hidden');
  $('hud').classList.add('hidden'); $('footer').classList.remove('hidden');
  $('start').innerHTML = '继续训练 <span>↗</span>';
}
async function start() {
  $('modal').classList.add('hidden'); $('menu').classList.add('hidden'); $('session-card').classList.add('hidden');
  $('hud').classList.remove('hidden'); $('footer').classList.add('hidden');
  active = true; held.clear(); edges.clear(); canvas.focus();
  try { await canvas.requestPointerLock(); }
  catch { toast('鼠标锁定不可用：按住鼠标左键拖动视角，方向键也可转动视角。', 5500); }
  try { audioContext ||= new AudioContext(); await audioContext.resume(); } catch { /* audio is optional */ }
}
$('start').addEventListener('click', start);
$('menu-button').addEventListener('click', pause);
document.addEventListener('pointerlockchange', () => {
  if (!document.pointerLockElement && active) pause();
});
document.addEventListener('pointerlockerror', () => toast('可按住鼠标左键拖动视角，或使用方向键。'));
canvas.addEventListener('mousedown', e => {
  if (!active) return;
  if (e.button === 2) held.add('Aim');
  if (e.button === 0) dragging = true;
});
window.addEventListener('mouseup', e => { if (e.button === 2) held.delete('Aim'); if (e.button === 0) dragging = false; });
window.addEventListener('mousemove', e => {
  if (!active || (!document.pointerLockElement && !dragging)) return;
  yaw -= e.movementX * sensitivity;
  pitch = THREE.MathUtils.clamp(pitch - e.movementY * sensitivity, -1.45, 1.45);
});
window.addEventListener('contextmenu', e => { if (e.target === canvas) e.preventDefault(); });
window.addEventListener('blur', () => { if (active) pause(); });
document.addEventListener('visibilitychange', () => { if (document.hidden && active) pause(); });
const gameKeys = new Set(['KeyW', 'KeyA', 'KeyS', 'KeyD', 'KeyC', 'ControlLeft', 'ControlRight', 'Space', 'ShiftLeft', 'ShiftRight', 'KeyQ', 'KeyE', 'KeyX', 'KeyR', 'KeyH', 'KeyT', 'ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown']);
window.addEventListener('keydown', e => {
  if (e.code === 'Escape') {
    if (!$('modal').classList.contains('hidden')) closeModal(); else if (active) pause(); return;
  }
  if (!active) return;
  if (gameKeys.has(e.code) || /^Digit[1-6]$/.test(e.code)) e.preventDefault();
  if (e.repeat) return;
  held.add(e.code); edges.add(e.code);
  if (e.code.startsWith('Shift')) shiftDownAt = performance.now();
  if (e.code === 'KeyR') { resetCheckpoint(); return; }
  if (e.code === 'KeyH') { showHelp(); return; }
  if (e.code === 'KeyT') { startRoute(); return; }
  if (/^Digit[1-6]$/.test(e.code)) teleport(Number(e.code.slice(-1)) - 1);
});
window.addEventListener('keyup', e => {
  held.delete(e.code);
  if (active && gameKeys.has(e.code)) e.preventDefault();
  if (active && e.code.startsWith('Shift') && performance.now() - shiftDownAt < 180) edges.add('KeyQ');
});
function readInput() {
  return { x: Number(held.has('KeyD')) - Number(held.has('KeyA')), z: Number(held.has('KeyW')) - Number(held.has('KeyS')),
    jumpHeld: held.has('Space'), jumpPressed: edges.has('Space'),
    crouch: held.has('KeyC') || held.has('ControlLeft') || held.has('ControlRight'),
    crouchPressed: edges.has('KeyC') || edges.has('ControlLeft') || edges.has('ControlRight'),
    sprint: held.has('ShiftLeft') || held.has('ShiftRight'), rollPressed: edges.has('KeyQ'),
    aim: held.has('Aim'), interactPressed: edges.has('KeyX'), slamPressed: edges.has('KeyE'), yaw, pitch };
}
function resetCheckpoint() {
  player.reset(); yaw = player.yaw; pitch = -.14; snapCamera = true; history.length = 0;
  if (route.active) { route.active = false; toast('已回到检查点。计时已取消，按 T 重新开始。'); }
  else toast('已回到 ' + spawns[player.checkpoint].name);
}
function teleport(index) {
  player.checkpoint = index; player.reset(); yaw = player.yaw; pitch = -.12; snapCamera = true;
  held.clear(); edges.clear(); history.length = 0;
  if (route.active) { route.active = false; toast('切换训练区后计时已取消，按 T 重新开始。'); }
  else toast(`${index + 1} / ${spawns[index].name} · ${zoneDescriptions[index]}`);
}
const zoneDescriptions = ['自由尝试全部动作', '冲刺后按 C 穿过通道', '向墙跳，按住空格连续蹬墙', '子弹跳 → 二段跳 → 右键滑翔', '靠近发光绳索按 X', '坡面滑铲与台阶测试'];
function startRoute() {
  player.checkpoint = 0; player.reset(); yaw = 0; pitch = -.14; snapCamera = true;
  route = { ...route, active: true, finished: false, index: 0, time: 0 };
  toast('计时开始：依次穿过 8 个金色圆环。自由选择移动方式。', 4000);
}
function formatTime(seconds) {
  return `${String(Math.floor(seconds / 60)).padStart(2, '0')}:${(seconds % 60).toFixed(2).padStart(5, '0')}`;
}
function checkRoute(dt) {
  if (!route.active) return;
  route.time += dt;
  const g = gates[route.index];
  if (player.position.clone().add(new THREE.Vector3(0, .9, 0)).distanceTo(new THREE.Vector3(g.x, g.y, g.z)) < g.r + .25) {
    route.index++;
    if (route.index === gates.length) {
      route.active = false; route.finished = true;
      if (!route.best || route.time < route.best) { route.best = route.time; safeStore.set('best', String(route.time)); }
      toast(`路线完成 · ${formatTime(route.time)} · 按 T 再来一次`, 6000);
    } else toast(`检查环 ${route.index} / 8 · 继续前往金色圆环`, 1500);
  }
}
function openModal(title, markup) {
  pause(); $('modal-title').textContent = title; $('modal-content').innerHTML = markup;
  $('modal').classList.remove('hidden'); $('close-modal').focus();
}
function closeModal() { $('modal').classList.add('hidden'); $('start').focus(); }
$('close-modal').addEventListener('click', closeModal);
$('modal').addEventListener('click', e => { if (e.target === $('modal')) closeModal(); });
document.addEventListener('keydown', e => {
  if (e.code !== 'Tab' || $('modal').classList.contains('hidden')) return;
  const items = [...$('modal').querySelectorAll('button, input, a[href]')];
  const first = items[0], last = items.at(-1);
  if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
  else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
});
const controls = [
  ['奔跑 / 冲刺', '无耐力限制', 'WASD / 按住 Shift'],
  ['蹲行 / 滑铲', '移动时蹲下会保留动量', '按住 C（或 Ctrl）'],
  ['子弹跳', '蹲伏或滑铲时跳，朝准星方向发射', 'C + 空格'],
  ['跳跃 / 二段跳', '空中再次按；蹬墙刷新空中次数', '空格 / 再按空格'],
  ['翻滚 / 空中翻滚', 'WASD 决定方向，可接在跳跃后', 'Q / 轻点 Shift'],
  ['瞄准滑翔', '减缓下落，可保留水平动量', '空中按住鼠标右键'],
  ['纵向 / 横向蹬墙', '正对墙向上，沿墙方向横移', '靠墙 + 方向 + 按住空格'],
  ['壁面攀附 / 跳离', '空中贴墙攀附；攀附时跳离墙面', '右键 / 空格'],
  ['攀越边缘', '接近可达边缘会自动翻上平台', '面向边缘 + W + 空格'],
  ['空中滑踢', '空中蹲伏，落地衔接滑铲', '空中按 C'],
  ['绳索平衡', '靠近绳索交互，上下绳都用 X', 'X · WASD 移动'],
  ['俯冲落地', '只实现落地位移；Q 可取消俯冲', '空中按 E'],
  ['重落地取消', '落地前滑铲或翻滚可继续移动', '落地前 C / Q'],
  ['复位 / 训练区域', '掉出地图自动回当前检查点', 'R / 数字 1—6'],
];
const checklist = ['sprint', 'crouch', 'slide', 'bullet', 'double', 'roll', 'airRoll', 'glide', 'wallClimb', 'wallRun', 'latch', 'mantle', 'zipline', 'slam'];
function showHelp() {
  openModal('把动作连起来', `<div class="control-grid">${controls.map(([name, sub, key]) => `<div class="control-row"><div><span>${name}</span><small>${sub}</small></div><span>${key}</span></div>`).join('')}</div>
    <div class="manual-note"><strong>推荐连招</strong>　W + Shift → C → 空格 → 松开 C 再按空格 → Q → 鼠标右键 → C 着陆<br>浏览器中推荐用 C 蹲伏，避免 Ctrl + W 等快捷键。H 打开指南，Esc 释放鼠标并暂停。方向键可辅助转动视角。<br>一次离地：地面子弹跳后可二段跳；空中子弹跳占用二段跳次数。落地或蹬墙恢复空中动作。</div>
    <div class="eyebrow" style="margin-top:22px">已体验 ${checklist.filter(s => visited.has(s)).length} / 14</div><div class="checklist">${checklist.map(s => `<span class="${visited.has(s) ? 'done' : ''}">${visited.has(s) ? '✓ ' : ''}${LABELS[s]}</span>`).join('')}</div>`);
}
$('help-button').addEventListener('click', showHelp);
$('zones-button').addEventListener('click', () => {
  openModal('选择你的练习', `<div class="zone-grid">${spawns.map((s, i) => `<button class="zone-card" data-zone="${i}"><b>0${i + 1}</b><span>${s.name}<small>${zoneDescriptions[i]}</small></span></button>`).join('')}</div><div class="manual-note">训练中也可以按数字 1—6 切换区域。R 回到所选区域的起点。</div>`);
  document.querySelectorAll('[data-zone]').forEach(el => el.addEventListener('click', () => { teleport(Number(el.dataset.zone)); start(); }));
});
$('route-button').addEventListener('click', () => { startRoute(); start(); });
const settings = [
  ['sprintSpeed', '冲刺速度', 8, 18, .5], ['bulletSpeed', '子弹跳速度', 18, 34, .5],
  ['jumpSpeed', '跳跃力度', 7, 15, .1], ['gravity', '重力', 16, 36, .5],
  ['airAcceleration', '空中转向', 5, 32, 1], ['slideFriction', '滑铲摩擦', 1, 10, .2],
  ['glideDuration', '滑翔时长', 1, 6, .1], ['fov', '镜头视野', 55, 95, 1], ['sensitivity', '鼠标灵敏度', 1, 5, .1],
];
function showTuning() {
  openModal('找到你的手感', `${settings.map(([key, label, min, max, step]) => {
    const value = key === 'fov' ? baseFov : key === 'sensitivity' ? sensitivity * 1000 : player.config[key];
    return `<label class="tuning-row"><span>${label}</span><input data-setting="${key}" type="range" min="${min}" max="${max}" step="${step}" value="${value}"/><output>${Number(value.toFixed(1))}</output></label>`;
  }).join('')}<div class="tuning-footer"><label><input id="sound-setting" type="checkbox" ${soundEnabled ? 'checked' : ''}/> <span style="font-size:12px">动作音效</span></label><button id="reset-settings" class="secondary">恢复默认参数</button></div><div class="manual-note">移动数值是本 demo 的可调近似参数。鼠标、视野与音效偏好保存在本机；移动参数本次会话有效。<br>动作参考 <a href="https://www.warframe.com/en/game/quickstart#parkour" target="_blank" rel="noopener" style="color:var(--gold)">Warframe 官方指南 ↗</a>。角色为原创人形，未使用官方圣剑模型。</div>`);
  document.querySelectorAll('[data-setting]').forEach(el => el.addEventListener('input', () => {
    const key = el.dataset.setting, value = Number(el.value); el.nextElementSibling.textContent = value;
    if (key === 'fov') { baseFov = value; safeStore.set('fov', value); }
    else if (key === 'sensitivity') { sensitivity = value / 1000; safeStore.set('sensitivity', sensitivity); }
    else { player.config[key] = value; player.glideLeft = Math.min(player.glideLeft, player.config.glideDuration); }
  }));
  $('sound-setting').addEventListener('change', e => { soundEnabled = e.target.checked; safeStore.set('sound', soundEnabled); });
  $('reset-settings').addEventListener('click', () => {
    Object.assign(player.config, DEFAULTS); baseFov = 69; sensitivity = .0022; soundEnabled = true;
    safeStore.set('fov', baseFov); safeStore.set('sensitivity', sensitivity); safeStore.set('sound', true); showTuning();
  });
}
$('tuning-button').addEventListener('click', showTuning);

function updateCamera(dt) {
  const look = new THREE.Vector3(-Math.sin(yaw) * Math.cos(pitch), Math.sin(pitch), -Math.cos(yaw) * Math.cos(pitch));
  const right = new THREE.Vector3(Math.cos(yaw), 0, -Math.sin(yaw));
  const target = player.position.clone().add(new THREE.Vector3(0, player.height < 1 ? .85 : 1.4, 0));
  const aiming = held.has('Aim'), distance = aiming ? 3.4 : 5.8 + Math.min(player.speed * .024, .6);
  const desired = target.clone().addScaledVector(look, -distance).addScaledVector(right, .65);
  const vector = desired.clone().sub(target), length = vector.length();
  raycaster.set(target, vector.normalize()); raycaster.far = length;
  const hit = raycaster.intersectObjects(collisionMeshes, false)[0];
  if (hit) desired.copy(target).addScaledVector(vector, Math.max(.25, hit.distance - .25));
  if (snapCamera) { camera.position.copy(desired); snapCamera = false; }
  else camera.position.lerp(desired, 1 - Math.exp(-dt * 16));
  const correction = camera.position.clone().sub(target);
  raycaster.set(target, correction.clone().normalize()); raycaster.far = correction.length();
  const obstruction = raycaster.intersectObjects(collisionMeshes, false)[0];
  if (obstruction) camera.position.copy(target).addScaledVector(correction.normalize(), Math.max(.2, obstruction.distance - .18));
  character.root.visible = camera.position.distanceTo(target) > .65;
  camera.lookAt(target.clone().addScaledVector(look, 20));
  const fov = baseFov + (aiming ? -8 : Math.min(9, player.speed * .28));
  camera.fov = THREE.MathUtils.lerp(camera.fov, fov, 1 - Math.exp(-dt * 7)); camera.updateProjectionMatrix();
}
const mapCtx = $('minimap').getContext('2d');
function drawMap() {
  const ctx = mapCtx, scale = 1.82;
  ctx.clearRect(0, 0, 180, 230); ctx.save(); ctx.translate(90, 144);
  for (const b of solids) {
    ctx.fillStyle = b.kind === 'floor' ? '#54718144' : '#aac6d25c';
    ctx.fillRect(b.minX * scale, b.minZ * scale, b.w * scale, b.d * scale);
  }
  if (route.active) {
    const g = gates[route.index]; ctx.strokeStyle = '#ebc484'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(g.x * scale, g.z * scale, 5, 0, Math.PI * 2); ctx.stroke();
  }
  ctx.translate(player.position.x * scale, player.position.z * scale); ctx.rotate(-yaw);
  ctx.fillStyle = '#8dfff0'; ctx.beginPath(); ctx.moveTo(0, -5); ctx.lineTo(3.5, 4); ctx.lineTo(0, 2); ctx.lineTo(-3.5, 4); ctx.closePath(); ctx.fill(); ctx.restore();
}
function updateHUD() {
  $('speed').textContent = player.speed.toFixed(1); $('height').textContent = Math.max(0, player.position.y).toFixed(1);
  $('state').textContent = LABELS[player.state] || player.state;
  speedBars.forEach((el, i) => el.classList.toggle('on', i < player.speed / 2));
  $('bullet-ready').classList.toggle('spent', player.bulletUsed || player.doubleUsed);
  $('jump-ready').classList.toggle('spent', player.doubleUsed);
  $('roll-ready').classList.toggle('spent', player.airRollUsed);
  $('glide-meter').style.width = `${100 * player.glideLeft / player.config.glideDuration}%`;
  $('latch-meter').style.width = `${100 * player.latchLeft / player.config.latchDuration}%`;
  const nearestZone = spawns.reduce((a, b) => Math.hypot(player.position.x - a.x, player.position.z - a.z) < Math.hypot(player.position.x - b.x, player.position.z - b.z) ? a : b);
  $('zone-label').textContent = nearestZone.name;
  const rope = player.nearestRope();
  $('context').textContent = player.rope ? '空格 跳离 · X / C 下绳' : rope ? 'X 站上绳索' : player.state === 'latch' ? '空格 蹬墙跳离 · 松开右键 下落' : player.wall && !player.grounded ? '按住 空格 蹬墙 · 右键 攀附' : '';
  $('route-hud').classList.toggle('hidden', !route.active && !route.finished);
  $('mode-label').textContent = route.active ? '计时路线' : '自由训练';
  $('route-progress').textContent = `${String(Math.min(route.index + 1, 8)).padStart(2, '0')} / 08`;
  $('route-time').textContent = formatTime(route.time);
  $('route-best').textContent = route.best ? `最佳 ${formatTime(route.best)}` : '穿过金色圆环';
  if (history.length) $('combo').textContent = history.slice(-4).map(e => LABELS[e]).join(' → ');
  drawMap();
}
function consumeEvents() {
  for (const event of player.events.splice(0)) {
    visited.add(event.name); beep(event.name);
    if (!['land', 'reset', 'hardLand'].includes(event.name) && history.at(-1) !== event.name) history.push(event.name);
    if (history.length > 8) history.shift();
    if (event.name === 'reset') {
      yaw = player.yaw; snapCamera = true;
      if (route.active && route.time > .1) { route.active = false; toast('离开训练场，已回到起点。按 T 重新计时。'); }
    }
  }
}
let previous = performance.now(), hudElapsed = 0;
function frame(now) {
  const dt = Math.min((now - previous) / 1000, .05); previous = now; totalTime += dt;
  if (toastTimer > 0) { toastTimer -= dt; if (toastTimer <= 0) $('toast').classList.remove('show'); }
  if (active) {
    yaw += ((held.has('ArrowLeft') ? 1 : 0) - (held.has('ArrowRight') ? 1 : 0)) * dt * 1.8;
    pitch = THREE.MathUtils.clamp(pitch + ((held.has('ArrowUp') ? 1 : 0) - (held.has('ArrowDown') ? 1 : 0)) * dt * 1.3, -1.45, 1.45);
    accumulator += dt;
    while (accumulator >= fixed) {
      player.step(fixed, readInput()); edges.clear(); accumulator -= fixed;
      visited.add(player.state); checkRoute(fixed); consumeEvents();
    }
  }
  character.update(player, dt, totalTime); trail(player, dt); updateCamera(dt);
  gateMeshes.forEach((mesh, i) => {
    mesh.visible = route.active || (i === 0 && !active);
    mesh.material.opacity = i === route.index ? .9 : .12;
    mesh.material.color.setHex(i === route.index ? 0xe0bc7e : 0x8dfff0);
    mesh.children[0].rotation.z = totalTime * .3;
  });
  renderer.render(scene, camera);
  hudElapsed += dt; if (hudElapsed > .07) { updateHUD(); hudElapsed = 0; }
  requestAnimationFrame(frame);
}
window.addEventListener('resize', () => {
  renderer.setSize(innerWidth, innerHeight); camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix();
});
canvas.addEventListener('webglcontextlost', e => {
  e.preventDefault(); pause(); $('error').textContent = '图形上下文中断，请刷新页面重新进入训练场。'; $('error').classList.remove('hidden');
});
updateHUD(); requestAnimationFrame(frame);
// Development-only hooks for deterministic physics and browser acceptance tests.
if (import.meta.env.DEV && new URLSearchParams(location.search).has('test')) {
  window.__KINETIC__ = {
    player, teleport, startRoute,
    snapshot: () => ({ position: player.position.toArray(), velocity: player.velocity.toArray(), state: player.state,
      active, bulletUsed: player.bulletUsed, doubleUsed: player.doubleUsed, airRollUsed: player.airRollUsed,
      glideLeft: player.glideLeft, route: { ...route }, visited: [...visited], calls: renderer.info.render.calls }),
    look: (y, p) => { yaw = y; pitch = p; },
  };
  import('../tests/browser-harness.js').then(({ install }) => install(window.__KINETIC__));
}
